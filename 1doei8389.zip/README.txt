To run:

g++ -o deque-demo main.cpp Deque.cpp Node.cpp -std=c++11